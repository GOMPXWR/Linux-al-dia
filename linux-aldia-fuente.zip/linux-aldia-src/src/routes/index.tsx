import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ArrowLeft, ArrowUpRight, Check, Languages, RefreshCw, Rss } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DISTROS, getLinuxNews, type DistroId, type NewsItem } from "@/lib/news.functions";
import {
  siAlpinelinux, siArchlinux, siDebian, siElementary, siEndeavouros,
  siFedora, siGentoo, siKalilinux, siLinuxmint, siManjaro, siNixos,
  siOpensuse, siPopos, siSolus, siTails, siUbuntu, siVoidlinux, siZorin,
  siRockylinux, siAlmalinux, siCentos, siRedhat, siRaspberrypi, siQubesos,
  siKde, siDeepin, siLubuntu, siArtixlinux, siGarudalinux, siLinux,
  type SimpleIcon,
} from "simple-icons";

const logos: Partial<Record<DistroId, SimpleIcon>> = {
  ubuntu: siUbuntu, fedora: siFedora, arch: siArchlinux, debian: siDebian,
  opensuse: siOpensuse, mint: siLinuxmint, gentoo: siGentoo,
  alpine: siAlpinelinux, popos: siPopos, endeavour: siEndeavouros,
  nixos: siNixos, zorin: siZorin, manjaro: siManjaro,
  elementary: siElementary, kali: siKalilinux, void: siVoidlinux,
  tails: siTails, solus: siSolus, ubuntublog: siUbuntu, rocky: siRockylinux,
  alma: siAlmalinux, centos: siCentos, redhat: siRedhat, raspberry: siRaspberrypi,
  qubes: siQubesos, neon: siKde, deepin: siDeepin, lubuntu: siLubuntu,
  artix: siArtixlinux, garuda: siGarudalinux, mageia: siLinux, peppermint: siLinux,
  antix: siLinux, bodhi: siLinux, linuxlite: siLinux, ublue: siLinux,
};

const newsQuery = queryOptions({
  queryKey: ["linux-news"],
  queryFn: () => getLinuxNews(),
  staleTime: 5 * 60 * 1000,
  refetchOnWindowFocus: false,
});

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Linux al día — Noticias de distribuciones" },
    { name: "description", content: "Noticias actuales de Ubuntu, Fedora, Debian, Arch, Mint y más distribuciones Linux, con traducción al español." },
    { property: "og:title", content: "Linux al día — Noticias de distribuciones" },
    { property: "og:description", content: "Noticias actuales de distribuciones Linux en un solo lugar, con traducción al español." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Feed,
});

function timeAgo(iso: string | null) {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.max(1, Math.floor(diff / 60000));
  if (mins < 60) return `${mins} min`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} h`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} d`;
  return new Date(iso).toLocaleDateString("es-ES", { day: "numeric", month: "short", year: "numeric" });
}

function DistroLogo({ id, size = "normal" }: { id: string; size?: "normal" | "small" }) {
  const logo = logos[id as DistroId];
  return <span className={`distro-logo distro-${id} ${size === "small" ? "distro-logo-small" : ""}`} aria-hidden="true">
    {logo ? <svg viewBox="0 0 24 24" fill="currentColor"><path d={logo.path} /></svg> : <Rss size={19} />}
  </span>;
}

async function translateText(text: string) {
  if (!text) return "";
  const url = new URL("https://api.mymemory.translated.net/get");
  url.searchParams.set("q", text.slice(0, 480));
  url.searchParams.set("langpair", "en|es");
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error("No se pudo traducir");
  const result = await response.json() as { responseStatus?: number; responseData?: { translatedText?: string } };
  if (result.responseStatus !== 200 || !result.responseData?.translatedText) throw new Error("No se pudo traducir");
  const translated = document.createElement("textarea");
  translated.innerHTML = result.responseData.translatedText;
  return translated.value;
}

function Post({ item }: { item: NewsItem }) {
  const [translation, setTranslation] = useState<{ title: string; summary: string } | null>(null);
  const [translating, setTranslating] = useState(false);
  const [translationError, setTranslationError] = useState(false);

  async function toggleTranslation() {
    if (translation) { setTranslation(null); return; }
    setTranslating(true);
    setTranslationError(false);
    try {
      const [title, summary] = await Promise.all([translateText(item.title), translateText(item.summary)]);
      setTranslation({ title, summary });
    } catch {
      setTranslationError(true);
    } finally {
      setTranslating(false);
    }
  }

  return <article className="post">
    <DistroLogo id={item.sourceId} />
    <div className="post-body">
      <div className="post-head">
        <span className="post-name">{item.sourceName}</span>
        <span className="post-handle">{item.handle}</span>
        <span className="post-dot">·</span>
        <time className="post-date" dateTime={item.date ?? undefined}>{timeAgo(item.date)}</time>
      </div>
      <h2 className="post-title">{translation?.title ?? item.title}</h2>
      {(translation?.summary ?? item.summary) && <p className="post-text">{translation?.summary ?? item.summary}</p>}
      <div className="post-actions">
        <Button type="button" variant="ghost" size="sm" className="post-action" onClick={toggleTranslation} disabled={translating} aria-label={translation ? "Ver original" : "Traducir al español"}>
          <Languages size={16} /> {translating ? "Traduciendo…" : translation ? "Ver original" : "Traducir"}
        </Button>
        <Button variant="ghost" size="sm" className="post-action" asChild>
          <a href={item.link} target="_blank" rel="noreferrer noopener" aria-label={`Leer noticia en ${item.sourceName}`}>
            <ArrowUpRight size={16} /> Leer noticia
          </a>
        </Button>
      </div>
      {translationError && <p className="translation-error">La traducción no está disponible ahora. Inténtalo de nuevo.</p>}
    </div>
  </article>;
}

function Feed() {
  const [selected, setSelected] = useState<DistroId | null>(null);
  const { data, isPending, isError, refetch, isFetching } = useQuery(newsQuery);
  const items = useMemo(() => selected ? data?.items.filter(item => item.sourceId === selected) ?? [] : data?.items ?? [], [data, selected]);
  const current = DISTROS.find(d => d.id === selected);
  const filters = <><Button variant="ghost" className={`source-choice ${!selected ? "source-choice-active" : ""}`} onClick={() => setSelected(null)}><Rss size={19} /> Todas las noticias</Button>
    {DISTROS.map(d => <Button key={d.id} variant="ghost" className={`source-choice ${selected === d.id ? "source-choice-active" : ""}`} onClick={() => setSelected(d.id)} aria-pressed={selected === d.id}>
      <DistroLogo id={d.id} size="small" /> {d.distro} {selected === d.id && <Check className="choice-check" size={15} />}
    </Button>)}</>;

  return <div className="app-shell">
    <aside className="sidebar" aria-label="Distribuciones">
      <div className="sidebar-top"><span className="brand-word">FUENTES · RSS</span></div>
      <nav className="source-nav">{filters}</nav>
      <div className="sidebar-bottom"><span className="live-dot" /> Noticias de fuentes públicas</div>
    </aside>
    <main className="timeline">
      <header className="timeline-header">
        <div className="timeline-title-row">{selected && <Button variant="ghost" size="icon" className="back-button" onClick={() => setSelected(null)} aria-label="Volver a todas las noticias"><ArrowLeft size={20} /></Button>}
          <div><h1>{current?.distro ?? "Para ti"}</h1><p>{selected ? "Noticias de la distribución" : "Lo último del mundo Linux"}</p></div>
          <Button variant="ghost" size="icon" className="refresh-button" title="Actualizar noticias" aria-label="Actualizar noticias" onClick={() => refetch()} disabled={isFetching}><RefreshCw size={18} className={isFetching ? "spinning" : ""} /></Button>
        </div>
        <div className="mobile-filters" role="group" aria-label="Filtrar por distribución">
          <Button variant="ghost" className={`mobile-filter ${!selected ? "mobile-filter-active" : ""}`} onClick={() => setSelected(null)}>Todas</Button>
          {DISTROS.map(d => <Button key={d.id} variant="ghost" className={`mobile-filter ${selected === d.id ? "mobile-filter-active" : ""}`} onClick={() => setSelected(d.id)}><DistroLogo id={d.id} size="small" />{d.distro}</Button>)}
        </div>
      </header>
      <div className="timeline-content">
        {isPending && <div aria-label="Cargando noticias" className="loading-list">{[0,1,2,3].map(n => <div key={n} className="loading-post"><div className="loading-avatar"/><div className="loading-lines"><i/><i/><i/></div></div>)}</div>}
        {isError && <div className="feed-state"><p>No se pudieron cargar las noticias.</p><Button variant="outline" onClick={() => refetch()}>Reintentar</Button></div>}
        {data && items.length === 0 && <div className="feed-state"><p>No hay noticias recientes de {current?.distro ?? "estas distribuciones"}.</p><Button variant="outline" onClick={() => refetch()}>Actualizar</Button></div>}
        {items.map(item => <Post key={item.id} item={item} />)}
        {data && data.failedSources.length > 0 && <p className="feed-caveat">Algunas fuentes no respondieron: {data.failedSources.map(id => DISTROS.find(d => d.id === id)?.distro ?? id).join(", ")}.</p>}
        {data && <div className="timeline-end"><span>Estás al día</span><p>Las noticias se actualizan desde los sitios de cada distribución.</p></div>}
      </div>
    </main>
    <aside className="right-rail" aria-label="Acerca del feed">
      <div className="rail-heading">En portada <span className="live-dot" /></div>
      <p className="rail-caption">Noticias publicadas por las comunidades Linux, reunidas en un solo lugar.</p>
      <div className="rail-divider" />
      <h2>Fuentes</h2>
      <div className="rail-sources">{DISTROS.slice(0, 7).map(d => <div key={d.id} className="rail-source"><DistroLogo id={d.id} size="small" /><span>{d.distro}</span></div>)}</div>
      <p className="rail-note">{DISTROS.length} distribuciones · fuentes RSS públicas</p>
    </aside>
  </div>;
}
