import { createServerFn } from "@tanstack/react-start";

// Fuentes RSS públicas y gratuitas (sin clave de API). Se leen desde el
// servidor para evitar problemas de CORS y poder cachear la respuesta.
export const DISTROS = [
  { id: "ubuntu", name: "OMG! Ubuntu", handle: "@omgubuntu", distro: "Ubuntu", url: "https://www.omgubuntu.co.uk/feed" },
  { id: "fedora", name: "Fedora Magazine", handle: "@fedoramagazine", distro: "Fedora", url: "https://fedoramagazine.org/feed/" },
  { id: "arch", name: "Arch Linux", handle: "@archlinux", distro: "Arch", url: "https://archlinux.org/feeds/news/" },
  { id: "debian", name: "Debian", handle: "@debian", distro: "Debian", url: "https://www.debian.org/News/news" },
  { id: "opensuse", name: "openSUSE News", handle: "@opensuse", distro: "openSUSE", url: "https://news.opensuse.org/feed.xml" },
  { id: "mint", name: "Linux Mint Blog", handle: "@linuxmint", distro: "Linux Mint", url: "https://blog.linuxmint.com/?feed=rss2" },
  { id: "gentoo", name: "Gentoo News", handle: "@gentoo", distro: "Gentoo", url: "https://www.gentoo.org/feeds/news.xml" },
  { id: "alpine", name: "Alpine Linux", handle: "@alpinelinux", distro: "Alpine", url: "https://alpinelinux.org/atom.xml" },
  { id: "popos", name: "System76 Blog", handle: "@system76", distro: "Pop!_OS", url: "https://blog.system76.com/rss.xml" },
  { id: "endeavour", name: "EndeavourOS", handle: "@endeavouros", distro: "EndeavourOS", url: "https://endeavouros.com/news/feed/" },
  { id: "nixos", name: "NixOS Blog", handle: "@nixos", distro: "NixOS", url: "https://nixos.org/blog/announcements-rss.xml" },
  { id: "zorin", name: "Zorin Blog", handle: "@zorinos", distro: "Zorin OS", url: "https://blog.zorin.com/feed/" },
  { id: "manjaro", name: "Manjaro Forum", handle: "@manjaro", distro: "Manjaro", url: "https://forum.manjaro.org/c/announcements.rss" },
  { id: "elementary", name: "elementary Blog", handle: "@elementary", distro: "elementary OS", url: "https://blog.elementary.io/feed.xml" },
  { id: "kali", name: "Kali Linux", handle: "@kalilinux", distro: "Kali Linux", url: "https://www.kali.org/rss.xml" },
  { id: "mx", name: "MX Linux", handle: "@mxlinux", distro: "MX Linux", url: "https://mxlinux.org/feed/" },
  { id: "void", name: "Void Linux", handle: "@voidlinux", distro: "Void Linux", url: "https://voidlinux.org/atom.xml" },
  { id: "tails", name: "Tails", handle: "@tails", distro: "Tails", url: "https://tails.net/news/index.en.rss" },
  { id: "solus", name: "Solus", handle: "@solus", distro: "Solus", url: "https://getsol.us/index.xml" },
  { id: "ubuntublog", name: "Ubuntu Blog", handle: "@ubuntu", distro: "Ubuntu (Canonical)", url: "https://ubuntu.com/blog/feed" },
  { id: "rocky", name: "Rocky Linux", handle: "@rocky_linux", distro: "Rocky Linux", url: "https://rockylinux.org/rss.xml" },
  { id: "alma", name: "AlmaLinux Blog", handle: "@almalinux", distro: "AlmaLinux", url: "https://almalinux.org/blog/index.xml" },
  { id: "centos", name: "CentOS Blog", handle: "@centos", distro: "CentOS", url: "https://blog.centos.org/feed/" },
  { id: "redhat", name: "Red Hat Blog", handle: "@redhat", distro: "Red Hat", url: "https://www.redhat.com/en/rss/blog" },
  { id: "mageia", name: "Mageia Blog", handle: "@mageia_org", distro: "Mageia", url: "https://blog.mageia.org/en/feed/" },
  { id: "raspberry", name: "Raspberry Pi News", handle: "@raspberry_pi", distro: "Raspberry Pi OS", url: "https://www.raspberrypi.com/news/feed/" },
  { id: "qubes", name: "Qubes OS", handle: "@qubesos", distro: "Qubes OS", url: "https://www.qubes-os.org/feed.xml" },
  { id: "neon", name: "KDE neon Blog", handle: "@kdeneon", distro: "KDE neon", url: "https://blog.neon.kde.org/feed/" },
  { id: "deepin", name: "deepin", handle: "@deepinlinux", distro: "deepin", url: "https://www.deepin.org/en/feed/" },
  { id: "lubuntu", name: "Lubuntu", handle: "@lubuntu", distro: "Lubuntu", url: "https://lubuntu.me/feed/" },
  { id: "peppermint", name: "Peppermint OS", handle: "@peppermintos", distro: "Peppermint OS", url: "https://peppermintos.com/feed/" },
  { id: "antix", name: "antiX", handle: "@antixlinux", distro: "antiX", url: "https://antixlinux.com/feed/" },
  { id: "bodhi", name: "Bodhi Linux", handle: "@bodhilinux", distro: "Bodhi Linux", url: "https://www.bodhilinux.com/feed/" },
  { id: "artix", name: "Artix Linux", handle: "@artixlinux", distro: "Artix Linux", url: "https://artixlinux.org/feed.php" },
  { id: "garuda", name: "Garuda Linux Forum", handle: "@garudalinux", distro: "Garuda Linux", url: "https://forum.garudalinux.org/c/announcements.rss" },
  { id: "linuxlite", name: "Linux Lite Forum", handle: "@linuxlite", distro: "Linux Lite", url: "https://www.linuxliteos.com/forums/syndication.php" },
  { id: "ublue", name: "Universal Blue", handle: "@ublue", distro: "Bazzite / Bluefin", url: "https://universal-blue.discourse.group/latest.rss" },
] as const;

export type DistroId = (typeof DISTROS)[number]["id"];

export type NewsItem = {
  id: string;
  sourceId: string;
  sourceName: string;
  handle: string;
  distro: string;
  title: string;
  summary: string;
  link: string;
  date: string | null;
};

function decode(input: string) {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&amp;/gi, "&")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&#8217;|&#039;|&apos;/g, "'")
    .replace(/&#8220;|&#8221;/g, '"')
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCodePoint(Number(n)))
    .replace(/\s+/g, " ")
    .trim();
}

function pick(block: string, tag: string) {
  const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
  return m ? decode(m[1]!) : "";
}

function pickLink(block: string) {
  const href = block.match(/<link[^>]*href="([^"]+)"/i);
  if (href) return href[1]!;
  const guid = block.match(/<guid[^>]*>(https?:[^<]+)<\/guid>/i);
  if (guid?.[1] && !pick(block, "link")) return decode(guid[1]);
  return pick(block, "link");
}

function parseFeed(xml: string) {
  const blocks = xml.match(/<(item|entry)[\s>][\s\S]*?<\/(item|entry)>/gi) ?? [];
  return blocks.slice(0, 15).map((b) => ({
    title: pick(b, "title"),
    link: pickLink(b),
    summary: (pick(b, "description") || pick(b, "summary") || pick(b, "content")).slice(0, 320),
    date: pick(b, "pubDate") || pick(b, "updated") || pick(b, "published") || null,
  }));
}

export const getLinuxNews = createServerFn({ method: "GET" }).handler(async () => {
  const results = await Promise.all(
    DISTROS.map(async (source) => {
      try {
        const res = await fetch(source.url, {
          headers: { "User-Agent": "LinuxFeed/1.0", Accept: "application/rss+xml, application/xml, text/xml" },
          signal: AbortSignal.timeout(9000),
        });
        if (!res.ok) return { sourceId: source.id, error: `HTTP ${res.status}`, items: [] as NewsItem[] };
        const xml = await res.text();
        const items: NewsItem[] = parseFeed(xml)
          .filter((i) => i.title && i.link)
          .map((i, idx) => ({
            id: `${source.id}-${idx}-${i.link}`,
            sourceId: source.id,
            sourceName: source.name,
            handle: source.handle,
            distro: source.distro,
            title: i.title,
            summary: i.summary,
            link: i.link,
            date: i.date && !Number.isNaN(new Date(i.date).getTime()) ? new Date(i.date).toISOString() : null,
          }));
        return { sourceId: source.id, error: null as string | null, items };
      } catch (e) {
        return { sourceId: source.id, error: e instanceof Error ? e.message : "Error", items: [] as NewsItem[] };
      }
    }),
  );

  const items = results
    .flatMap((r) => r.items)
    .sort((a, b) => (b.date ?? "").localeCompare(a.date ?? ""));

  return {
    items,
    failedSources: results.filter((r) => r.error).map((r) => r.sourceId),
    fetchedAt: new Date().toISOString(),
  };
});
