import { Link } from '@tanstack/react-router';
import { useEffect, useState, type ReactNode } from 'react';
import { BookOpen, GitFork, Moon, Newspaper, Search, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function AppChrome({children}: {children: ReactNode}) {
 const [theme, setTheme] = useState<'dark'|'light'>('dark');
 useEffect(() => { const saved = window.localStorage.getItem('linux-theme'); document.documentElement.dataset['theme'] = saved === 'light' ? 'light' : 'dark'; if(saved === 'light') setTheme('light'); }, []);
 const toggleTheme = () => { const next = theme === 'dark' ? 'light' : 'dark'; setTheme(next); document.documentElement.dataset['theme'] = next; window.localStorage.setItem('linux-theme', next); };
 return <div className="site-frame"><header className="global-header"><Link className="site-logo" to="/" aria-label="Linux al día, noticias"><span className="logo-glyph">L<span>.</span></span><span>linux al día</span></Link><nav className="global-nav" aria-label="Secciones"><Link to="/" activeProps={{className:'nav-current'}} activeOptions={{exact:true}}><Newspaper size={17}/>Noticias</Link><Link to="/distribuciones" activeProps={{className:'nav-current'}}><Search size={17}/>Distribuciones</Link><Link to="/arbol" activeProps={{className:'nav-current'}}><GitFork size={17}/>El árbol</Link><Link to="/tutoriales" activeProps={{className:'nav-current'}}><BookOpen size={17}/>Tutoriales</Link></nav><Button className="theme-switch" variant="ghost" size="icon" title={theme === 'dark' ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'} aria-label={theme === 'dark' ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={19}/> : <Moon size={19}/>}</Button></header>{children}</div>;
}
