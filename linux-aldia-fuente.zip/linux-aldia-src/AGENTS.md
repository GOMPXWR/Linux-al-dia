<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The Linux news timeline reads public distro RSS/Atom feeds via one server function, keeping cross-origin fetching and failure isolation on the server.
- Per-post English-to-Spanish translation calls the public MyMemory endpoint on demand without storing translated content, avoiding a persistent backend for optional reading assistance.
- The distro directory and family tree share a static editorial catalog with explicit parent IDs; unknown relationships stay unset to avoid asserting lineage without evidence.
- The shared navigation wraps route content in the root route; section indexes and detail pages use nested TanStack routes so deep links render correctly.
- The dark-first theme is controlled by CSS tokens and a local browser preference; optional animation is disabled for reduced-motion users.
- The tutorial library stores reviewed, source-linked editorial content in client-safe data, separate from live RSS headlines.
