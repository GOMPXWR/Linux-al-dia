# Linux al día — Contexto del proyecto

## Qué es la página

Una web en español sobre Linux y sus distribuciones, con cuatro secciones:

1. **Noticias (`/`)** — Muro estilo X/Twitter con noticias reales leídas de los
   feeds RSS/Atom públicos de 37 distribuciones y proyectos (Ubuntu, Fedora,
   Arch, Debian, openSUSE, Mint, Gentoo, Alpine, Pop!_OS, EndeavourOS, NixOS,
   Zorin, Manjaro, elementary, Kali, MX, Void, Tails, Solus, Rocky, AlmaLinux,
   CentOS, Red Hat, Mageia, Raspberry Pi OS, Qubes OS, KDE neon, deepin,
   Lubuntu, Peppermint, antiX, Bodhi, Artix, Garuda, Linux Lite, Bazzite,
   Bluefin…). Se pueden filtrar por una o varias distribuciones y cada noticia
   tiene botón **Traducir** (inglés → español, API pública MyMemory, sin
   almacenar nada) y **Leer noticia** (enlace original).
2. **Distribuciones (`/distribuciones`)** — Catálogo buscable de **180
   distribuciones** con ficha individual por cada una (`/distribuciones/:slug`).
   Cada ficha muestra origen, derivadas, enlaces oficiales (sitio web y redes
   sociales obtenidos de Wikidata cuando existen) y guías relacionadas.
3. **El árbol (`/arbol`)** — Visualización interactiva del parentesco entre
   distribuciones (de qué proyecto deriva cada una), con pestañas por familia,
   zoom, búsqueda y una lista accesible alternativa. Al pulsar un nodo se abre
   su ficha.
4. **Tutoriales (`/tutoriales`)** — 7 guías paso a paso con comandos copiables
   y fuentes oficiales: primeros pasos tras instalar, instalar aplicaciones,
   actualizar el sistema, programas esenciales, alternativas libres a programas
   conocidos, jugar juegos de Windows (Steam/Proton, Lutris, Wine) y resolver
   problemas comunes.

## Decisiones de diseño y reglas

- **Tema negro por defecto**, con opción clara guardada en el navegador
  (localStorage `linux-theme`).
- Animaciones suaves tipo Hyprland (entradas escalonadas de tarjetas);
  desactivadas si el usuario tiene `prefers-reduced-motion`.
- Interfaz íntegramente en español.
- **Nada inventado**: sin métricas ficticias (no hay contadores de likes ni
  retuits), sin parentescos ni datos de fichas sin verificar — cuando falta
  información se muestra «[sin verificar]» o «[no disponible]».
- Sin APIs de pago ni claves: los feeds se leen desde el servidor (evita CORS)
  y la traducción usa MyMemory bajo demanda.

## Arquitectura técnica

- TanStack Start v1 (React 19 + Vite 7), Tailwind CSS v4 con tokens en
  `src/styles.css`.
- `src/lib/news.functions.ts` — función de servidor que descarga y parsea los
  feeds RSS/Atom (regex, sin dependencias) y devuelve `{items, failedSources,
  fetchedAt}`.
- `src/lib/distros.data.json` — catálogo de 180 distribuciones (id, nombre,
  parentId). 108 con padre verificado, 72 raíces, sin ciclos ni enlaces rotos.
- `src/lib/catalog.ts` — tipos y helpers del catálogo (familias, descendientes,
  enlaces oficiales, datos editoriales).
- `src/lib/guides.ts` — las 7 guías con secciones, comandos y fuentes.
- `src/components/AppChrome.tsx` — navegación global y alternador de tema.
- Logos de distribuciones con `simple-icons`.

## Qué falta / ideas en desarrollo o sin terminar

1. **Fichas incompletas**: de las 180 distribuciones, solo las ~12 familias
   principales tienen descripción editorial verificada. El resto muestra
   «Origen por verificar» / «[no disponible]». Falta redactar y verificar
   información detallada (qué es, a quién conviene, puntos fuertes, entorno de
   escritorio, modelo de actualizaciones, paquetería, instalación) para cada
   ficha, con fuentes individuales.
2. **Fotos y vídeos por distribución**: el plan aprobado incluye capturas y
   vídeos con procedencia y permisos verificables en cada ficha. Hoy solo hay
   una imagen editorial genérica (`src/assets/linux-desktop-editorial.jpg`).
   Faltan los materiales verificables de la mayoría de fichas.
3. **El árbol es superficial**: solo muestra 1 nivel de derivados directos
   (hasta 8 subramas por nodo). Ideas pendientes: vista de profundidad
   completa, más subramas, y enriquecer relaciones (108 de 180 tienen padre;
   el resto son raíces o de origen no confirmado).
4. **Animaciones tipo Hyprland parciales**: solo hay entradas escalonadas
   (`tile-enter`). Faltan transiciones de paneles y microinteracciones más
   elaboradas (siempre respetando `prefers-reduced-motion`).
5. **Más fuentes de noticias**: algunas distribuciones (Kubuntu, Xubuntu,
   Nobara, Vanilla OS…) no publican RSS legible y no están en el muro.
6. **Redes oficiales**: se muestran solo cuando Wikidata las tiene; muchas
   fichas aún muestran «[no disponible]».

## Cómo ejecutarlo

```bash
bun install
bun run dev   # http://localhost:8080
```

No requiere claves ni variables de entorno.
